# 🚀 Taskbar Liquid Lyrics — v1.1.1 現況交接與 v1.2.0 升級修正計畫書（專家協作版）

> **專案名稱**：工作列液態玻璃動態歌詞器 (`Taskbar Liquid Lyrics`)  
> **目前穩定基準版本**：`v1.1.1`（已完成源碼整合、PyInstaller 單一資料夾封裝與實機回歸驗證）  
> **目標升級版本**：`v1.2.0`  
> **文件目的**：向專家報告目前 `v1.1.1` 已穩定運作之基礎架構，並針對實機測試發現之 **4 項核心問題與升級需求**，提供完整原始碼級別（Line-by-Line）根因分析與 `v1.2.0` 建議修改架構，供專家審閱並實作 `v1.2.0` 新版。

---

## 一、 前期進度回顧：`v1.1.1` 已完成且運作正常之基礎（請務必保留）

在 `v1.0.0` 至 `v1.1.1` 的迭代中，以下核心模組已經過實機驗證運作順暢，請專家在實作 `v1.2.0` 時**維持既有架構與相容性，切勿回退**：

1. **三態生命周期狀態機 (`playing` / `pure_audio` / `standby`)**：
   - `ui/js/app.js` 已實作無音訊超時（預設 `5.0s`）平滑淡出進入 `standby` 休眠，並停止持續性 `requestAnimationFrame` 迴圈以釋放 CPU/GPU 負載。
   - 非 GSMTC 之純系統音訊持續達門檻（預設 `300ms`）時，自動進入 `pure_audio` 狀態並顯示「偵測到系統音訊」。
2. **WASAPI Loopback 音訊採樣與三頻段波浪融合演算法**：
   - `main.py` 採樣使用 Hann Window FFT 並提取 `bass`、`energy`、`mid`、`high` 四組特徵，透過 WebSocket (`@a,bass,energy,mid,high`) 推送至 `ui/js/wave_engine.js`，波浪視覺與幀率表現極佳。
3. **外觀控制中心與 Windows 系統整合 (`v1.1.1`)**：
   - 支援 4 種液態玻璃風格、字體顏色、膠囊寬度、多螢幕錨點定位、點擊穿透、開機自動啟動（HKCU Run 登錄檔）與桌面捷徑建立（UTF-8 無亂碼 `.lnk`）。

---

## 二、 `v1.2.0` 四大核心問題根因分析與架構修正方案

在實機日常使用（長時間待機喚醒、多分頁播放 YouTube 影片與音樂）時，發現 **2 個嚴重體驗瑕疵** 與 **2 項歌詞核心能力缺口**。以下為我們對目前專案原始碼的深度追蹤與建議解法：

---

### 🔴 問題 1：長時間使用後，膠囊外圍會突然出現「實心深色黑底方塊」（需 100% 完整去背）

#### 1. 實機現象與 Log 證據
- **現象**：剛啟動程式時，膠囊外圍與圓角完全透明去背正常；但使用一段時間（或經過休眠喚醒、切換全螢幕應用／分頁）後，膠囊背後會突然浮現一個 **944×85 px（150% DPI 下對應邏輯尺寸 624×56 px）的實心深灰黑底矩形方塊 (`#202020`)**，完全破壞透明水晶質感（見隨附壓縮包內 `bug_screenshots/螢幕擷取畫面 2026-10-30 012627.png`）。
- **`tll.log` 關鍵證據**：
  在黑底發生的時間點（`01:26:27`），前端效能監控回報：
  ```text
  [perf] {'cmd': 'perf', 'frames': 46, 'avg': 168.42, 'p95': 209.6, 'slow34': 45, 'slow100': 45, 'top5': [205, 210, 210, 212, 7168], 'evt': 'state:playing->pure_audio ', 'state': 'pure_audio'}
  ```
  在狀態切換前，WebView2 渲染執行緒曾被凍結／休眠長達 **`7168 ms`**！

#### 2. 原始碼根因定位 (`main.py` & `ui/css/style.css`)
1. **`ALPHA_MODE = "dwm"` 下完全停用了 `SetWindowRgn` 視窗幾何裁切**：
   - 見 `main.py` 第 `206` 行：`ALPHA_MODE = "dwm"`；第 `1230`、`1359`、`1389` 行：`if ALPHA_MODE != "dwm": apply_capsule_region(hwnd)`。
   - 這導致 Win32 底層視窗（含 `WindowsForms10.Window` 與子視窗 `Chrome_WidgetWin_0` / `Intermediate D3D Window`）在作業系統層級**始終是一塊完整的 624×56 矩形視窗**，圓角外圍與 Padding 區域完全仰賴 DWM Alpha 合成與 WebView2 的 `DefaultBackgroundColor = Color.Transparent`。
2. **`reapply()` 僅在啟動前 4 秒執行，缺乏後續自癒機制**：
   - 見 `main.py` 第 `1398` 行：`for delay in (0.2, 0.8, 2.0, 4.0): threading.Timer(delay, reapply).start()`。啟動 4 秒後再也不會重刷 DWM 透明屬性或 WebView2 背景色。
3. **WebView2 背景遮蔽節流 (Occlusion Throttling) 與 DirectComposition 表面重置**：
   - 當膠囊進入 `standby` 休眠（`opacity: 0` 且停止 `rAF`）或系統發生 DWM 重置／GPU 交換鏈重建時，Chromium (`msedgewebview2.exe`) 判定視窗無更新而回收／重建 DirectComposition 透明表面，回退為 Chromium 預設深色背景 `#202020`，整塊 624×56 矩形瞬間變成黑底。

#### 3. 我們建議的 `v1.2.0` 解決方案（請專家評斷與實作）
1. **注入 WebView2 啟動參數，禁止 Chromium 回收透明渲染表面 (`main.py`)**：
   - 在 `import webview` 與 `webview.start()` 之前設定環境變數：
     ```python
     os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = (
         "--disable-backgrounding-occluded-windows "
         "--disable-renderer-backgrounding "
         "--disable-features=CalculateNativeWinOcclusion "
         "--default-background-color=00000000"
     )
     ```
2. **休眠態 (`standby`) 連動作業系統級別視窗透明度歸零 (`main.py` + `app.js`)**：
   - 當 `app.js` 的 `standbyClearTimer`（440ms 淡出完成後）觸發時，透過 WebSocket 發送 `{"cmd": "set_standby_os", "standby": true}` 給 Python 主程式；喚醒時發送 `{"cmd": "set_standby_os", "standby": false}`。
   - Python 收到 `standby: true` 時，將 Win32 視窗 `SetLayeredWindowAttributes(hwnd, 0, 0, LWA_ALPHA)`（或 `form.Opacity = 0.0`），從 OS 層級徹底隱形，**物理上杜絕待機時出現黑塊的可能**；收到 `standby: false` 時立即恢復 `alpha = 255` 並同步觸發一次 `reapply_transparency()`。
3. **新增 DWM 與 WebView2 透明表面守護機制 (Transparency Watchdog)**：
   - 將 `setup_liquid_window` 內的透明設定封裝為可重入的 `reapply_transparency(hwnd, form)`：每次從 `standby` 喚醒、調整視窗寬度／風格、以及定時（低開銷 UI 執行緒檢查）重新確保 `enable_dwm_transparency(hwnd)` 與 `wv.DefaultBackgroundColor = Drawing.Color.Transparent` 有效，並評估搭配適度外擴的圓角 `SetWindowRgn` 裁掉四角多餘的矩形緩衝區。

---

### 🔴 問題 2：播放 ILLIT 的歌卻出現「台視新聞 TTV NEWS」前綴（嚴禁記憶殘留、多音訊採「後者覆蓋」、直接跑馬燈顯示當下影片名）

#### 1. 實機現象
- 使用者在瀏覽器播放 YouTube 官方 MV：`ILLIT (아일릿) '체포하겠어 (You're Under Arrest)' Official MV`，膠囊跑馬燈卻顯示：
  **`台視新聞 TTV NEWS | ILLIT (아일릿) '체포하겠어 (You're Under Arrest)' Official MV`**（見 `bug_screenshots/螢幕擷取畫面 2026-10-30 011134.png`）。

#### 2. 原始碼根因定位（為什麼會把舊分頁／新聞台拼進來？）
1. **根因 A：存在「狀態記憶殘留」與「欄位拼湊」 (`ui/js/app.js` 第 110–112 行 & 第 548–560 行)**
   - 在 `app.js` 中，`currentTrack` 是一個全域共用物件 (`{ title, artist, album, duration, isPlaying }`)。
   - 當透過 WebNowPlaying (`handleWnpMessage`) 或跨分頁更新時，`TITLE` 與 `ARTIST` 是分開寫入 `currentTrack` 的，舊分頁殘留的 `artist`（例如先前開過的 `台視新聞 TTV NEWS`）沒有被徹底清空！
   - 更糟的是，`showTrackInfo()`（第 110 行）硬性規定把 `${currentTrack.artist} | ${currentTrack.title}` 拼在一起顯示，導致舊的 `artist` 跟新的 `title` 被強行接成一串！
2. **根因 B：`main.py` 的 `media_worker` 未實作「多音訊後者覆蓋 (Last-Active Wins)」 (`main.py` 第 874–884 行)**
   ```python
   session = manager.get_current_session()
   if not session:
       sessions = manager.get_sessions()
       ...
   ```
   - `manager.get_current_session()` 只會抓 Windows 預設的單一工作階段（常常抓到已經暫停或背景的分頁），當使用者同時開多個分頁或切換不同音訊來源時，沒有做到**「誰最後開始播放，就立刻完全覆蓋前一個來源」**。

#### 3. 設計原則與 `v1.2.0` 解決方案（不需要黑白名單！純粹靠「零記憶殘留 + 後者覆蓋 + 直接顯示當下影片／曲目名」）
1. **跑馬燈直接顯示當下播放的 YT 影片名／曲目名稱 (`ui/js/app.js` -> `showTrackInfo`)**：
   - **完全不需要維護什麼頻道黑白名單**！
   - 膠囊在顯示曲目跑馬燈時，只要乾乾淨淨地把**當下正在播放的影片／曲目標題 (`currentTrack.title`)** 以跑馬燈形式顯示即可（若只有純音樂軟體且無影片標題結構時才輔助顯示，絕不把舊分頁或無關的頻道名硬接在前面）。
2. **徹底消除記憶功能（Zero Memory Retention）**：
   - 無論是進入休眠 (`standby`)、切換工作階段 (`session_id` 改變)、或是新影片／新曲目開始播放時，**必須將先前的 `currentTrack` 狀態 100% 清零重置**，絕對不保留上一部影片或上一個分頁的任何欄位，避免新舊資料混血。
3. **偵測多音訊／多來源時，嚴格採用「後者覆蓋 (Last-Started Wins)」(`main.py` + `app.js`)**：
   - 在 `main.py` 的 `media_worker` 中，掃描 `manager.get_sessions()` 所有工作階段，追蹤各個 Session 狀態轉為 `PlaybackStatus.PLAYING`（或標題變更且處於 `PLAYING`）的時間戳記：
     - **只要偵測到有新的音訊／影片來源開始播放（後者），立即以「後者覆蓋前者」的方式切換目標工作階段**，並整包覆蓋前端顯示，徹底解決多分頁、多播放器之間的搶佔與衝突！
     - 同理，若 GSMTC 與 WebNowPlaying 同時存在，以最後觸發有效播放事件的來源整包覆蓋，禁止單獨局部修改 `artist` 欄位。

---

### 🟡 問題 3：多模態／多來源歌詞擷取偵測與最佳版本評分（參考 YouTube Music 的 Apple Music 介面擴充套件生態）

#### 1. 靈感來源與現有主流開源歌詞來源盤點
夥伴最初的設計靈感來自 **「將 YouTube Music 改造為 Apple Music 逐字動態歌詞介面」的知名開源瀏覽器擴充套件**。經完整盤點該領域兩大旗艦開源專案 **YouLy+ (`ibratabian17/YouLyPlus` / `LyricsPlus` KPOE 生態系)** 與 **Better Lyrics (`boidu14/better-lyrics`)**，它們之所以能高命中率抓到精準時間軸與逐字歌詞，是因為採用了以下多來源架構：

| 歌詞來源 / API | 在 YTM Apple Music 擴充套件中的角色 | 支援格式與優勢 |
| :--- | :--- | :--- |
| **1. YouLy+ / LyricsPlus 聚合 API**<br>(`/v2/lyrics/get?source=apple,lyricsplus,musixmatch,qq,spotify`) | **YouLy+ 核心主力來源**<br>透過多鏡像站同時檢索 5 大上游庫：<br>• `apple` (**Apple Music 官方 TTML 逐字庫**)<br>• `musixmatch` / `musixmatch-word` (**YTM 官方合作全球歌詞庫**)<br>• `qq` (**QQ 音樂 QRC 亞洲與 K-pop 逐字庫**)<br>• `spotify` (**Spotify 同步歌詞庫**)<br>• `lyricsplus` (**KPOE 社群校對庫**) | 支援 **Apple Music 等級逐字音節同步 (Syllable Sync)** 與逐行同步，品質最高 |
| **2. Better Lyrics API / `lrc.red`**<br>(`https://lyrics-api.boidu.dev/getLyrics`) | **Better Lyrics 核心主力來源**<br>整合 `lrc.red` (Apple Music TTML 快取) 與 `Unison` 社群貢獻庫 | 對 YouTube / YTM 影片標題與曲長相容性極佳 |
| **3. LRCLIB 開放歌詞庫**<br>(`https://lrclib.net/api/search`) | **YouLy+ 與 Better Lyrics 共同標準備援庫** | 速度最快（100~200ms），全球開源社群維護之標準 `.lrc` |
| **4. 網易雲音樂 (NetEase) / 酷狗音樂 (Kugou)** | **亞洲桌面端／擴充套件常用加強源**（需透過 Python 後端免 CORS 代理呼叫） | 對韓團 K-pop（如 ILLIT）、日文歌、華語獨立音樂收錄極廣 |

#### 2. 為什麼目前專案 (`ui/js/lyrics_engine.js`) 已經寫了 `LYRICSPLUS_MIRRORS` 卻還是常抓錯或抓不到？
我們檢查 [`ui/js/lyrics_engine.js`](file:///C:/Users/yexia/Documents/ShihWei/NTNU/GitHub/%E8%A6%96%E8%A6%BA%E5%8B%95%E6%85%8B%E6%95%88%E6%9E%9C/PC/Taskbar_Liquid_Lyrics/ui/js/lyrics_engine.js) 發現了 **3 個關鍵缺陷**：
1. **缺陷 1：`LRCLIB` 提早攔截，導致 `LyricsPlus` (Apple Music / QQ / Musixmatch) 被直接丟棄！**
   - 看 `lyrics_engine.js` 第 `972–982` 行 (`fetchOnline`)：
     ```javascript
     const lrcLibPromise = this.fetchFromLrcLib(pair.title, pair.artist, durationSec, signal);
     const lyricsPlusPromise = this.fetchFromLyricsPlus(pair.title, pair.artist, durationSec, signal);

     const lrcLibRes = await lrcLibPromise;
     if (lrcLibRes && lrcLibRes.length >= 4 && this.sessionId === session && !signal.aborted) {
       ...
       this.applyLyrics(lrcLibRes, session);
       return; // <-- 致命缺陷：只要 LRCLIB 有 4 行以上，就直接 return，完全不等待也不比較 LyricsPlus 的結果！
     }
     ```
   - 這造成只要 `LRCLIB` 上有一份時間軸不準或對應錯誤的歌詞，程式就盲目採用，把 `LyricsPlus` 抓到的高品質 Apple Music / Musixmatch / QQ 歌詞直接丟掉！
2. **缺陷 2：`LyricsPlus` 鏡像站清單過舊且未帶入完整 `source` 參數**：
   - 第 `18–22` 行只放了 3 個舊鏡像，缺少 YouLy+ 目前主力的高可用鏡像（如 `https://lyricsplus.atomix.one`、`https://lyricsplus.binimum.org`），且第 `880` 行請求時未明確指定 `?source=apple,lyricsplus,musixmatch,qq,spotify`。
3. **缺陷 3：YouTube 影片標題多模態拆解不足**：
   - 當播放 YouTube MV 時，影片標題為 `"ILLIT (아일릿) '체포하겠어 (You're Under Arrest)' Official MV"`。搜尋歌詞時，需要自動從這串 YT 標題中拆出：
     - 歌手變體：`ILLIT`、`아일릿`
     - 歌名變體：`체포하겠어`（韓文主歌名）、`You're Under Arrest`（括號內英文副歌名）、`체포하겠어 (You're Under Arrest)`
     再用這些變體去多來源歌詞網平行檢索。

#### 3. 我們建議的 `v1.2.0` 解決方案
1. **升級多來源歌詞池（全面對齊 YouLy+ 與 Better Lyrics 架構）**：
   - **前端平行檢索**：
     - **YouLy+ (`LyricsPlus`) 5 大鏡像池**：`lyricsplus.atomix.one`、`lyricsplus.binimum.org`、`lyricsplus.prjktla.my.id`、`lyricsplus.prjktla.workers.dev`、`lyricsplus-seven.vercel.app`（帶入 `source=apple,lyricsplus,musixmatch,qq,spotify`）。
     - **Better Lyrics API**：`https://lyrics-api.boidu.dev/getLyrics?s={title}&a={artist}&d={duration}`。
     - **LRCLIB API**：`https://lrclib.net/api/search`。
   - **Python 後端免 CORS 輔助代理 (`main.py`)**：
     - 新增網易雲音樂 (`music.163.com`) 與酷狗音樂 (`kugou.com`) LRC 搜尋代理，透過 WebSocket 回傳給前端共同參與評分。
2. **廢除「先到先贏」，改為「多來源平行收集 + 最佳版本智慧評分 (`BestMatchScorer`)」**：
   - 平行發起所有歌詞源請求（設定快速聚合視窗，或先顯示首個合格版本，當高分版本抵達時無縫替換），針對所有回傳版本統一計算品質分數：
     - **來源與逐字精度加權**：具備逐字音節同步 (`words.length > 1`，來自 Apple Music / QQ / Musixmatch) 加 `+50` 分。
     - **歌曲時長吻合度 (`Duration Delta`)**：候選歌詞時長與當前播放影片／音訊 `duration` 誤差 `≤ 2.5s` 加 `+80` 分；誤差 `≤ 6.0s` 加 `+40` 分；誤差過大扣分。
     - **多模態歌名／歌手吻合度**：比對拆解後的主歌名、括號副歌名與歌手名稱。
     - **語系真實性與時間軸健康度**：K-pop 歌曲優先保留含韓文諺文 (`[\uac00-\ud7af]`) 之原版歌詞（過濾純英文拼音版）；時間軸必須單調遞增且行數合理（過濾少於 5 行的殘缺版）；所有簡體中文自動經 `S2TConverter` 轉為台灣正體中文。
   - 保留評分前 5 名的候選版本清單，供使用者在 UI 手動切換。

---

### 🟢 問題 4：新增「歌詞校正功能」（自動校正 + 控制中心 UI 手動微調與版本切換）

#### 1. 實機需求與目前原始碼缺口
- **夥伴需求**：「我希望新增歌詞校正功能，無論自動、手動修正都要這樣，手動可以加入在 UI。」
- **原始碼根因定位**：
  1. **嚴重漏接 Bug：`app.js` 主渲染迴圈完全忽略了 `lyricsEngine.offset`！**
     - 看 [`ui/js/app.js`](file:///C:/Users/yexia/Documents/ShihWei/NTNU/GitHub/%E8%A6%96%E8%A6%BA%E5%8B%95%E6%85%8B%E6%95%88%E6%9E%9C/PC/Taskbar_Liquid_Lyrics/ui/js/app.js#L643) 第 `643` 行：
       ```javascript
       for (let i = lyrics.length - 1; i >= 0; i--) {
         if (estimatedPosition >= lyrics[i].time - 0.15) { activeIndex = i; break; }
       }
       ```
     - `app.js` 直接拿 `estimatedPosition` 跟 `lyrics[i].time` 比較，**完全沒有加上 `lyricsEngine.offset`**！而且第 `68` 行初始化 `LyricsEngine` 時傳入 `viewportId: null`，導致 `lyrics_engine.js` 裡的滾輪微調 (`bindViewportOffsetWheel`) 從未綁定生效！
  2. **缺乏自動時間軸校正機制**。
  3. **[`ui/settings.html`](file:///C:/Users/yexia/Documents/ShihWei/NTNU/GitHub/%E8%A6%96%E8%A6%BA%E5%8B%95%E6%85%8B%E6%95%88%E6%9E%9C/PC/Taskbar_Liquid_Lyrics/ui/settings.html) 完全沒有歌詞時間軸微調與手動選詞介面**。

#### 2. 我們建議的 `v1.2.0` 解決方案
1. **修復 `app.js` 時間軸偏移計算並實作「自動歌詞校正 (Auto-Calibration)」**：
   - **修復偏移套用**：在 `appLoop` 中改為 `const effectivePos = Math.max(0, estimatedPosition + (lyricsEngine ? lyricsEngine.offset : 0));`。
   - **自動校正機制**：
     - **LRC 原生 `[offset:+/-ms]` 標籤解析**。
     - **YouTube MV 與音源時長差／前奏人聲自動對齊**：當播放 YouTube 官方 MV（通常比純音源多出片頭劇情或片尾，導致 `track.duration` 與歌詞庫標準時長 `lrcDuration` 存在差值），或結合 WASAPI 中頻人聲頻段 (`mid`) 首次能量突破點，自動補償時間軸偏移，讓歌詞精準對上開口唱的第一句！
2. **在控制中心 (`ui/settings.html`) 新增「🎤 歌詞校正與多來源切換」UI 面板**：
   - 在 `ui/settings.html` 新增專屬液態玻璃面板，透過 WebSocket 與主膠囊即時雙向連動：
     1. **當前播放與歌詞來源狀態顯示**：顯示當前影片／曲目名稱、目前採用的歌詞來源（如 `Apple Music / QQ / Musixmatch / LRCLIB / 網易雲`）與目前偏移秒數（如 `0.0s`）。
     2. **手動時間軸微調按鈕組 & 滑桿**：
        - 提供 `[-1.0s]` `[-0.5s]` `[-0.1s]` `[重置 0.0s]` `[+0.1s]` `[+0.5s]` `[+1.0s]` 快捷按鈕，點擊立即透過 WebSocket (`cmd: "adjust_lyrics_offset"`) 即時修正膠囊歌詞進度。
        - 同時支援直接用滑鼠滾輪在膠囊上滾動微調 `±0.2s`（中鍵歸零）。
     3. **候選歌詞版本下拉切換 & 手動關鍵字搜尋框**：
        - 下拉選單列出多來源抓到的所有候選歌詞版本（顯示來源名稱、歌名、歌手、時長、匹配分數），如果覺得自動選的版本不對，一鍵下拉即可切換成其他來源版本！
        - 附帶「手動輸入歌名／歌手搜尋歌詞」輸入框，遇到標題完全沒寫歌名的特殊影片也能手動指定歌詞。

---

## 三、 建議修改檔案清單

| 檔案路徑 | `v1.2.0` 預計修改重點 |
| :--- | :--- |
| [`main.py`](file:///C:/Users/yexia/Documents/ShihWei/NTNU/GitHub/%E8%A6%96%E8%A6%BA%E5%8B%95%E6%85%8B%E6%95%88%E6%9E%9C/PC/Taskbar_Liquid_Lyrics/main.py) | 1. 設定 `WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS` 防止透明表面被回收。<br>2. 新增 `set_standby_os`（休眠時 OS 視窗透明度歸零）與 DWM 透明自癒守護。<br>3. `media_worker` 實作「多音訊後者覆蓋 (Last-Active Wins)」與零記憶殘留切換。<br>4. 新增後端免 CORS 歌詞檢索代理與歌詞校正 WebSocket 指令轉發。<br>5. 更新 `APP_VERSION = "1.2.0"`。 |
| [`ui/js/lyrics_engine.js`](file:///C:/Users/yexia/Documents/ShihWei/NTNU/GitHub/%E8%A6%96%E8%A6%BA%E5%8B%95%E6%85%8B%E6%95%88%E6%9E%9C/PC/Taskbar_Liquid_Lyrics/ui/js/lyrics_engine.js) | 1. 升級多模態 YT 標題拆解（供歌詞搜尋使用，拆出主歌名、括號副歌名、內嵌歌手）。<br>2. 對齊 **YouLy+ (`LyricsPlus`)** 與 **Better Lyrics** 架構：擴充 5 大鏡像站並帶入 `source=apple,lyricsplus,musixmatch,qq,spotify`，串接 `lyrics-api.boidu.dev`、LRCLIB 與後端網易雲／酷狗。<br>3. 廢除 LRCLIB 提早 `return`，改為多來源平行收集 + `BestMatchScorer` 智慧評分，並保留候選清單供 UI 切換。<br>4. 實作自動時長差／前奏偏移校正與手動 `setOffset` 介面。 |
| [`ui/js/app.js`](file:///C:/Users/yexia/Documents/ShihWei/NTNU/GitHub/%E8%A6%96%E8%A6%BA%E5%8B%95%E6%85%8B%E6%95%88%E6%9E%9C/PC/Taskbar_Liquid_Lyrics/ui/js/app.js) | 1. **零記憶殘留 + 後者覆蓋**：切換曲目／音訊時徹底重置 `currentTrack`，`showTrackInfo()` 直接以跑馬燈顯示當下播放的 YT 影片名／曲目名，不拼湊殘留的 `artist`。<br>2. 修復 `appLoop` 第 643 行未套用 `lyricsEngine.offset` 之 Bug。<br>3. 串接控制中心 UI 之歌詞時間軸微調、候選版本切換、手動關鍵字搜尋與膠囊滾輪微調。 |
| [`ui/settings.html`](file:///C:/Users/yexia/Documents/ShihWei/NTNU/GitHub/%E8%A6%96%E8%A6%BA%E5%8B%95%E6%85%8B%E6%95%88%E6%9E%9C/PC/Taskbar_Liquid_Lyrics/ui/settings.html) | 新增「🎤 歌詞智慧校正與版本切換」面板（顯示當前曲目與來源、自動校正開關、`-1.0s ~ +1.0s` 時間微調按鈕、多來源候選版本下拉選單、手動關鍵字搜尋框）。 |

---

## 四、 給專家的交付請求

請專家審閱上述 4 點根因分析與 `v1.2.0` 修改架構是否完善：
1. 請基於隨附之 `v1.1.1` 完整源碼壓縮包直接實作 **`v1.2.0` 完整源碼 ZIP** 與 **`HANDOFF_v1.2.0.md` 交接報告**。
2. 我們收到 `v1.2.0` 源碼包後，會在本地端 Windows 11 實機執行 `build.ps1` 封裝 PyInstaller 執行檔並進行完整實機驗收。
