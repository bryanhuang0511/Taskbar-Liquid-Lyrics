# 🧊 Taskbar Liquid Lyrics (工作列液態玻璃歌詞器)

> **專為 Windows 11 設計的高幀率、全透明、音訊響應式工作列懸浮歌詞膠囊**  
> 純綠色免安裝（Portable）架構・DWM 每像素 Alpha 完美穿透・144Hz 滿幀流體彩虹波浪・GSMTC 全域媒體同步

---

## 🌟 專案亮點

- **💎 真・每像素 Alpha 透明（DWM Per-pixel Alpha）**：  
  告別色鍵（Color Keying）鋸齒紫邊與傳統 Region 硬切階梯感。透過 DWM 底層 API 延伸框架與清空色鍵，實現極致純淨的半透明磨砂玻璃與抗鋸齒平滑邊界。
- **🌊 144Hz 滿幀事件驅動波浪引擎（Canvas 2D）**：  
  前端採用純 Canvas 2D 渲染，具備子步長插值（Sub-step Interpolation）與全域 TypedArray 零 GC 配置。平均每幀耗時僅 6.95ms，實現滿幀無延遲。
- **🎵 GSMTC 全域多媒體與歌詞同步**：  
  自動監聽 Windows 系統媒體傳輸控制（Spotify、Chrome、Edge、KKBOX、Apple Music 等），即時顯示歌曲、歌手與高靈敏動態滾動歌詞。
- **⚡ 非同步音訊管線（Local WebSocket）**：  
  WASAPI 環回音訊採樣後，透過本機專屬 WebSocket 直推前端，徹底解耦 WinForms UI 執行緒，規避跨執行緒同步卡頓與緩衝區溢位。
- **📦 純綠色可攜式架構（Portable）**：  
  解壓即用，免安裝、零註冊表殘留、不佔用 AppData，可自由放置於任何硬碟路徑或隨身碟隨身攜帶。

---

## 🚀 快速開始（使用者）

### 下載與執行
1. 下載最新源碼交接包 `TaskbarLiquidLyrics_v1.1.0_Source_For_Expert.zip`。
   > 此交接包提供原始碼與測試；Windows 可攜執行版需在 Windows / Python 3.12 環境執行 `build.ps1` 建置。
2. 解壓縮至任意資料夾（建議放置於固定工具目錄，如 `D:\Tools\TaskbarLiquidLyrics`）。
3. 在 Windows PowerShell 進入該資料夾，執行 `PowerShell -ExecutionPolicy Bypass -File .\build.ps1 -Python "python.exe 的完整路徑"`；完成後執行 `dist\TaskbarLiquidLyrics\TaskbarLiquidLyrics.exe`。

### 操作與控制
* **位置定錨**：預設自動居中浮動於 Windows 11 工作列頂端（支援 150% 等任意 DPI 縮放自動對齊）。
* **系統匣控制（System Tray）**：
  - 右鍵點擊右下角通知區的小圖示，可快速切換：
    - 🔒 **鎖定位置（Lock Position）**：鎖定時防止滑鼠誤拖，被拖動時自動彈回定錨點。
    - 👻 **點擊穿透（Click-Through）**：開啟後滑鼠點擊直接穿透至下方工作列或視窗。
    - ⚙️ **外觀控制中心（Settings）**：開啟獨立設定視窗調整尺寸、風格與音訊增益。
    - ❌ **結束程式（Exit）**：安全釋放音訊環回線程與系統匣資源。

---

## ⚙️ 設定檔說明 (`config.json`)

程式同目錄下的 `config.json` 支援即時自訂參數：

```json
{
  "width": 640,
  "height": 44,
  "x": 669,
  "y": 0,
  "style": 1,
  "text_color": "white",
  "audio_gain": 2.2,
  "silence_timeout_seconds": 5.0,
  "audio_active_threshold": 0.25,
  "audio_confirm_ms": 300,
  "monitor": 0,
  "anchor": "custom",
  "topmost": true,
  "locked": true,
  "click_through": false,
  "snap": true,
  "edge_test": false,
  "extend_frame": true
}
```

* `style`: 
  - `1`: **全透明流體玻璃（Pure Crystal）**（預設最極致透明感）
  - `2`: 暗黑靈動島（Obsidian Dynamic Island）
  - `3`: 霓虹極光（Neon Aurora Wave）
  - `4`: 磨砂冰霜（Frosted Snow Ice）
* `audio_gain`: 音訊起拍敏感度（建議值 `2.2`）。
* `silence_timeout_seconds`: 超過多少秒沒有達到音訊門檻就淡出並進入透明休眠，預設 `5.0`，範圍 1–120 秒。
* `audio_active_threshold`: 音訊活動門檻；整體 energy 約 0.25 對應本專案 `-60dBFS` 正規化範圍中的 `-45dBFS`，預設 `0.25`。
* `audio_confirm_ms`: 必須連續高於音訊門檻的時間，預設 `300` 毫秒，避免短促聲響誤觸發純音訊模式。

---

## 🏗️ 系統架構圖

```
┌────────────────────────────────────────────────────────┐
│                   Windows 11 系統層                    │
│   [WASAPI 環回採樣]           [GSMTC 媒體/歌詞]        │
└──────────┬─────────────────────────────┬───────────────┘
           │ (PCM 44.1kHz 音訊區塊)      │ (曲目元數據)
           ▼                             ▼
┌────────────────────────────────────────────────────────┐
│                  Python 3.12 後端服務                  │
│  - WASAPI Worker: 2048 點 Hann 窗 FFT (Bass/Mid/High)  │
│  - GSMTC Worker: WinRT 非同步監聽播放器狀態            │
│  - DWM Manager: Win32 API 視窗樣式與 Per-pixel Alpha   │
│  - 本地 WebSocket 伺服器 (ws://127.0.0.1:8974)         │
└──────────────────────────┬─────────────────────────────┘
                           │ ~11.6ms 頻率即時推播 (@a,bass,energy,mid,high)
                           ▼
┌────────────────────────────────────────────────────────┐
│             前端視窗 (WebView2 / EdgeChromium)         │
│  - app.js: 接收 WebSocket 音訊封包，防抖排程 DOM 更新  │
│  - wave_engine.js: 144Hz 滿幀 Canvas 2D 物理傳播波浪   │
│  - style.css: inset box-shadow 擬態無外框純淨流體玻璃  │
└────────────────────────────────────────────────────────┘
```

---

## 🛠️ 開發與建置（開發者）

### 環境需求
- Windows 10 / 11 64-bit
- Python 3.12 64-bit
- Microsoft Visual C++ 2015-2022 Redistributable (x64)

### 一鍵打包（PyInstaller onedir 目錄模式）
```powershell
# 執行自動化建置指令碼，自動收納 VC++ 執行階段與 CLR 預載檢驗
.\build.ps1 -Python "python.exe的路徑"
```

### 自動化驗收測試
```powershell
# 背景拉起編譯完成的 exe，檢驗 CLR 預載、UI 執行緒注入與日誌無 Fatal Error
.\verify_build.ps1
```

---

## 📜 版本歷程

- **v1.1.0 (休眠與系統音訊回退)** (2026-10-25)
  - 新增 `standby` / `playing` / `pure_audio` 三態狀態機。
  - 音訊停止達到設定超時後，文字淡出、清空歌詞／曲名／歌手，膠囊回歸真正透明。
  - standby 完成後停止前端 requestAnimationFrame 與 Canvas 繪製；有效音訊／曲目事件會喚醒動畫。
  - 加入非 GSMTC 音訊回退：音訊高於門檻連續 300ms、且沒有正在播放的有效曲目時顯示「偵測到系統音訊」，不執行歌詞檢索。
  - GSMTC 有效播放資料具有優先權；找不到媒體工作階段時清空後端保存的舊 metadata。
  - 新增 Node.js 前端生命週期 mock 回歸測試 `dev_tests/test_v110_lifecycle.js`。

- **v1.0.0 (官方正式版)** (2026-10-25)
  - 奠定 DWM Per-pixel Alpha 純透明穿透管線，視窗實體整數像素精準對齊。
  - 導入本地專屬 WebSocket 音訊推播，徹底解放 WinForms UI 執行緒。
  - 後端升級 2048 點 Hann 窗滑動 FFT（21.5Hz 高解析度）與 `-42dBFS` 線性動態映射。
  - 前端重寫事件驅動波浪引擎，實現旋律與重低音動態融合（`base + (peak - baseAvg) * env`），低音擊打時主唱旋律不被吞沒。
  - 支援開機自動啟動（使用者層級 HKCU 登錄檔，免系統管理員，含防抖重試）。
  - 自動維護桌面捷徑（採用原生 Unicode COM 防護，支援 OneDrive 重定向桌面與中文目錄路徑）。
  - 全新液態磨砂玻璃設定控制中心（560×820 視窗）與全新玻璃八分音符 App 圖示。
  - 採用 PyInstaller `onedir` 純綠色免安裝可攜架構（Portable ZIP）。

---

## 📄 授權與宣告
本專案為個人開源桌面動態增強小工具，致力於呈現極致的視覺美學與客觀工程質量。
