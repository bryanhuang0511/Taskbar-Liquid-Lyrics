## [v1.1.0] - 2026-10-25 (Auto-Sleep + Pure Audio Fallback)

### 新增
- `standby` / `playing` / `pure_audio` 三態前端狀態機。
- 靜音超時後文字平滑淡出並清空，膠囊背景、邊框與陰影回歸純透明；同時 reset 歌詞引擎並取消進行中的歌詞請求。
- 休眠淡出完成後停止 requestAnimationFrame 與 Canvas 繪製；有效播放或音訊事件喚醒後恢復原生刷新節奏。
- 非 GSMTC 音訊回退：能量門檻連續維持指定時間後顯示「偵測到系統音訊」，不進行無效歌詞查詢。
- `config.json` 新增 `silence_timeout_seconds`、`audio_active_threshold`、`audio_confirm_ms`。
- GSMTC 無工作階段時主動清空舊曲目 metadata，避免殘留舊歌名。

### 驗證
- `node --check ui/js/app.js`
- `node --check ui/js/wave_engine.js`
- `python -m py_compile main.py`
- `node dev_tests/test_v110_lifecycle.js`
- `python -I dev_tests/test_system.py main.py`（系統整合 mock；原測試中的 APP_VERSION 固定值同步調整為 1.1.0）

### 範圍限制
- 目前交付為源碼／資產／測試交接 ZIP，尚未在本環境建立 Windows PyInstaller 可攜執行檔；WASAPI、GSMTC、WebView2 與 DWM 必須在 Windows 實機做最終驗收。

# Taskbar Liquid Lyrics 更新日誌 (CHANGELOG)

## [v1.0.0] - 2026-10-25 (官方首發正式版 Milestone Release)

專為 Windows 11 設計的高幀率、全透明、音訊響應式工作列懸浮歌詞膠囊。

### 🌟 核心特色
1. **DWM 每像素 Alpha 純透明**：
   - 告別色鍵紫邊與硬切鋸齒，透過 DWM 底層 API 延伸框架與清空色鍵，實現極致半透明磨砂玻璃與抗鋸齒平滑邊界。
2. **事件驅動波浪引擎與旋律融合**：
   - 合成公式 `base + (peak - baseAvg) * env`：重低音衝擊波最高達 85%，中高音人聲起伏（17%~44%）直接疊加在浪頭擺動，重音退去時主唱旋律無縫接手，不被低音吞沒平化。
3. **開機自動啟動（免系統管理員）**：
   - 寫入 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`。
   - 具備 3 秒緩衝延遲、搬家自動修正路徑、GSMTC 服務延遲重試。
4. **自動維護桌面捷徑**：
   - 封裝版首次啟動自動建立桌面捷徑（`config.json` 的 `shortcut_auto_done`；刪除後不重複強行生成）。
   - 採用原生 Unicode COM 防護，支援 OneDrive 重定向桌面與中文目錄路徑。
5. **全新液態玻璃圖示與設定中心**：
   - 內外嵌合「透明玻璃球 + 白色八分音符」多尺寸圖示（16~256px，含真 Alpha）。
   - 560×820 懸浮磨砂玻璃面板、動態玻璃滑桿與微光色球背景。
6. **純綠色免安裝可攜架構（Portable）**：
   - 解壓即用、不佔用 AppData、零註冊表殘留。
